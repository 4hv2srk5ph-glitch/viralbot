async function refresh(){
 const s=await fetch("/api/status").then(r=>r.json());
 document.querySelector("#status").className=s.youtube?"ok":"";
 document.querySelector("#ytStatus").textContent=s.youtube?"YouTube bağlı ✅":"YouTube bağlı değil";
 document.querySelector("#connect").style.display=s.youtube?"none":"block";
 document.querySelector("#logout").style.display=s.youtube?"block":"none";
 const jobs=await fetch("/api/jobs").then(r=>r.json());
 document.querySelector("#count").textContent=jobs.length;
 document.querySelector("#jobs").innerHTML=jobs.map(j=>`<div class="job"><b>${j.id}</b><br>${j.topic||"Viral video"} — ${j.status}<div class="bar"><div class="fill" style="width:${j.progress}%"></div></div></div>`).join("")||"<p>Henüz görev yok.</p>";
}
document.querySelector("#generate").onclick=async()=>{
 await fetch("/api/create-job",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic:"Günün viral konusu"})});
 refresh();
};
document.querySelector("#upload").onsubmit=async e=>{
 e.preventDefault();
 const btn=e.target.querySelector("button"); btn.disabled=true; btn.textContent="⏳ YouTube'a yükleniyor...";
 const r=await fetch("/api/upload",{method:"POST",body:new FormData(e.target)});
 const j=await r.json();
 const box=document.querySelector("#message");
 if(r.ok) box.innerHTML=`<p class="ok">✅ Yüklendi! Video ID: ${j.video_id}</p><p><a href="${j.url}" target="_blank">YouTube'da aç</a></p>`;
 else box.innerHTML=`<p class="error">❌ ${j.error||"Hata"}</p>${j.connect_url?'<a class="button" href="'+j.connect_url+'">YouTube hesabını bağla</a>':''}`;
 btn.disabled=false; btn.textContent="📤 YouTube'a Yükle";
 refresh();
};
refresh(); setInterval(refresh,3000);
